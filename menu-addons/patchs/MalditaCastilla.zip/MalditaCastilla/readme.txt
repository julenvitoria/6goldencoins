-----------------------------------------

MALDITA CASTILLA  �2012
Released 12/12/2012
Version 1.1

A game by Locomalito
Music by Gryzor87
Cover art by Marek Barej

-----------------------------------------

INGAME CONTROLS
Arrows ------ Move and aim
X ----------- Jump
Z ----------- Attack

Esc --------- Pause menu
Alt+Enter --- Toggle fullscreen
Alt+f4 ------ Rage quit

-----------------------------------------

This is a free traditional videogame.
If you feel it worth it, you can support
this and other future projects making a 
donation or spreading the word about it.

If you want to know more about my games
enter www.locomalito.com

-----------------------------------------

Have fun :-)

-----------------------------------------